package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utils.AbstractPage;
import utils.ItemDetails;

public class CartPage extends AbstractPage {
	
	public CartPage(WebDriver driver) {
		super(driver);

	}
	public String getPrice(){
		String price = driver.findElement(By.cssSelector("[class='a-color-price hlb-price a-inline-block a-text-bold']")).getText();
		System.out.println(price);	
//		driver.findElement(By.cssSelector("[class='a-color-price hlb-price a-inline-block a-text-bold']")).getText();
		return price;
//		return price;
	}
	
	public CartPage goToCart(){
		driver.findElement(By.linkText("Cart")).click();
		return new CartPage(driver);
	}
	

	public String getCartSubtotal(){
		String subtotal = driver.findElement(By.cssSelector("[class='a-size-medium a-color-price sc-price sc-white-space-nowrap  sc-price-sign']")).getText();
		System.out.println(subtotal);
//		driver.findElement(By.cssSelector("[class='a-size-medium a-color-price sc-price sc-white-space-nowrap  sc-price-sign']")).getText();
//		return new ItemDetails(driver);
		return subtotal;
	}
}
