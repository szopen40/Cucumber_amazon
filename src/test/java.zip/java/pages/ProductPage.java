package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import utils.AbstractPage;

public class ProductPage extends AbstractPage {

	public ProductPage(WebDriver driver) {
		super(driver);
	}

	public ProductPage selectQuantity(){
		WebElement dropdown = driver.findElement(By.name("quantity"));		
		Select drop = new Select(dropdown);
		drop.selectByValue("2");
		return new ProductPage(driver);
	}
	
	public CartPage addToCart(){
		driver.findElement(By.xpath("//input[@id='add-to-cart-button']")).click();
		return new CartPage(driver);
	}
}
