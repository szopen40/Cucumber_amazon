package utils;

import org.openqa.selenium.WebDriver;

import pages.CartPage;
import pages.HomePage;

public class ItemDetails extends AbstractPage {

	public ItemDetails(WebDriver driver) {
		super(driver);
	}

	CartPage prices = new CartPage(driver);
	
	String prajs = prices.getCartSubtotal().toString();
	
	public String expectedPrice(){
		String price_expected = prices.getPrice().toString();
		return price_expected;
	}
	
	public String subtotalPrice(){
//		CartPage cart = new CartPage(driver);
		String subtotal = prices.getCartSubtotal().toString();
		return subtotal;
	}
}